(function() {
  $(function() {
    return $('select').selectpicker();
  });

}).call(this);
